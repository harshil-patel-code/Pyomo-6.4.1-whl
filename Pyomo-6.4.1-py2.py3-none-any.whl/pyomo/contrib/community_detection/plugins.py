def load():
    import pyomo.contrib.community_detection.detection

def load():
    import pyomo.contrib.gdpbb.GDPbb
